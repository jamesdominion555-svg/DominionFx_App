package fx.dominion.app

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.Button
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(){
    var start by remember { mutableStateOf(false) }
    val scale = animateFloatAsState(if (start) 1.05f else 0.9f, animationSpec = tween(durationMillis = 1200))
    LaunchedEffect(true){
        start = true
        delay(1800)
    }

    Box(modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0B0B0B), Color(0xFF023269))))){
        Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center){
            Box(modifier = Modifier.size(180.dp).scale(scale.value)) {
            }
            Spacer(modifier = Modifier.height(20.dp))
            Text("DominionFx", color = Color.White)
            Spacer(modifier = Modifier.height(8.dp))
            Text("Precision. Discipline. Profit.", color = Color(0xFFFFD700))
            Spacer(modifier = Modifier.height(40.dp))
            Text("© 2025 DominionFx", color = Color.LightGray)
        }
    }
}

@Composable
fun Dashboard(){
    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF0B0B0B)).padding(16.dp)){
        Text("$5000.00", color = Color.White)
        Spacer(modifier = Modifier.height(12.dp))
        Button(onClick = {}){ Text("Add Trade") }
    }
}
