# DominionFx_App

Upload this repository to GitHub as `DominionFx_App` and open with Gitpod:

https://gitpod.io/#https://github.com/<your-username>/DominionFx_App

Gitpod will auto-run the build script and serve app-debug.apk on port 8000.
