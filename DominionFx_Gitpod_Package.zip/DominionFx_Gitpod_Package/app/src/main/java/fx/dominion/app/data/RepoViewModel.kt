package fx.dominion.app.data

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class TradeRepository(private val db: AppDatabase){
  private val dao = db.tradeDao()
  suspend fun all() = dao.all()
  suspend fun add(t: Trade) = dao.insert(t)
  suspend fun update(t: Trade) = dao.update(t)
}

class MainViewModel(context: Context): ViewModel(){
  private val db = Room.databaseBuilder(context, AppDatabase::class.java, "dominionfx-db").build()
  private val repo = TradeRepository(db)
  private val _trades = MutableStateFlow<List<Trade>>(emptyList())
  val trades: StateFlow<List<Trade>> = _trades

  fun loadTrades(){
    viewModelScope.launch { _trades.value = repo.all() }
  }
  fun addTrade(t: Trade){ viewModelScope.launch { repo.add(t); loadTrades() } }
}
