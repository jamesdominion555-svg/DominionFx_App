#!/usr/bin/env bash
set -e
echo "DominionFx Gitpod auto-build starting..."
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64 || true
cd app
if [ ! -f ./gradlew ]; then
  echo "Generating gradle wrapper..."
  gradle wrapper --gradle-version 7.6 || true
fi
chmod +x ./gradlew || true
./gradlew assembleDebug --no-daemon
APK="app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK" ]; then
  echo "APK built: $APK"
  cd app/build/outputs/apk/debug
  python3 -m http.server 8000 --bind 0.0.0.0 &
  tail -f /dev/null
else
  echo "APK not found."
  exit 1
fi
