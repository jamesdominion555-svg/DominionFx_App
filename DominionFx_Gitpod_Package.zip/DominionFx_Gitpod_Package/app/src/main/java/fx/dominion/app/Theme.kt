package fx.dominion.app

import androidx.compose.material.darkColors
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Typography
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorPalette = darkColors(
  primary = Color(0xFF034694),
  primaryVariant = Color(0xFF023269),
  secondary = Color(0xFFFFD700)
)

@Composable
fun DominionFxTheme(content: @Composable() () -> Unit) {
  MaterialTheme(
    colors = DarkColorPalette,
    typography = Typography(),
    shapes = androidx.compose.material.Shapes(),
    content = content
  )
}
