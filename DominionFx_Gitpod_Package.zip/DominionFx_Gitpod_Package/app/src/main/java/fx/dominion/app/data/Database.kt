package fx.dominion.app.data

import androidx.room.*

@Entity(tableName = "trades")
data class Trade(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val pair: String,
  val side: String,
  val lots: Double,
  val entry: Double,
  val sl: Double?,
  val tp: Double?,
  val openTime: Long,
  val closeTime: Long?,
  val pnl: Double?,
  val notes: String?,
  val tags: String?
)

@Dao
interface TradeDao {
  @Query("SELECT * FROM trades ORDER BY openTime DESC")
  suspend fun all(): List<Trade>
  @Insert suspend fun insert(t: Trade): Long
  @Update suspend fun update(t: Trade)
  @Delete suspend fun delete(t: Trade)
}

@Database(entities = [Trade::class], version = 1)
abstract class AppDatabase: RoomDatabase() {
  abstract fun tradeDao(): TradeDao
}
